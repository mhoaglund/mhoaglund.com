var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

var renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );
THREE.ImageUtils.crossOrigin = ''; //enabling cross-domain image loading

var geometry = new THREE.BoxGeometry(1,1,1);
var material = new THREE.MeshBasicMaterial( { color: 0x00ff00 } );
var cube = new THREE.Mesh( geometry, material );
scene.add( cube );

var geometry = new THREE.PlaneGeometry( 5, 20 );
var material = new THREE.MeshBasicMaterial( {color: 0xffff00, side: THREE.DoubleSide} );
var plane = new THREE.Mesh( geometry, material );
scene.add( plane );

camera.position.z = 5;

function render() {
	requestAnimationFrame(render);
	renderer.render(scene, camera);
	cube.rotation.x += 0.1;
	cube.rotation.y += 0.1;
}
render();

var images = [];
$.ajax({
    url: "http://api.tumblr.com/v2/blog/mhoaglund.tumblr.com/posts?api_key=4tSmOqIkIEzatqvtIjBwrEyprY6sohK4tRObRVhq2uKEPOJGLk",
    dataType: 'jsonp',
    success: function(info){
      getImages(info);
    }
});

function getImages(obj){
	var lump = obj.response.posts;
	lump.foreach(function(o){
		images.add(o.photos.original_size.url); 
		console.log("added" + o.date);
	});
}
//var mapOverlay = THREE.ImageUtils.loadTexture('http://i.imgur.com/3tU4Vig.jpg');